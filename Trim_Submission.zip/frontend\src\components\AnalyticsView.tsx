import React from "react";
export const AnalyticsView = ({ data, onClose }: any) => (
  <div style={{ background: "#eff6ff", border: "1px solid #bfdbfe", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
    <div style={{ display: "flex", justifyContent: "space-between" }}>
      <h3>Real-time Metrics Tracker</h3>
      <button onClick={onClose} style={{ background: "#ef4444", color: "#fff", border: "none", cursor: "pointer", padding: "4px 8px" }}>Close</button>
    </div>
    <p>Total Confirmed Clicks: <strong>{data.totalClicks}</strong></p>
    <div>
      <h4>Device Breakdown</h4>
      {Object.entries(data.deviceBreakdown).map(([k, v]: any) => <div key={k}>{k}: <strong>{v}</strong></div>)}
      <h4>Referrer Breakdown</h4>
      {Object.entries(data.referrerBreakdown).map(([k, v]: any) => <div key={k}>{k}: <strong>{v}</strong></div>)}
    </div>
  </div>
);