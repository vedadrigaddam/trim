# AI Usage

* **Tools used**: Cursor / Claude 3.5 Sonnet
* **Where it helped**: Interface visual styling layouts scaffolding configurations.
* **Where it erred**: Initially recommended a caching 301 redirect architecture which blocks real-time downstream analytics tracking. I caught this and manually implemented a 302 redirect protocol.
* **One thing I deliberately did NOT delegate**: Configuration optimization strategies for database schema index structures.