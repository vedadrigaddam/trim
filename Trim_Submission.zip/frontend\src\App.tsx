import React, { useState, useEffect } from "react";
import { AnalyticsView } from "./components/AnalyticsView";

export default function App() {
  const [links, setLinks] = useState([]);
  const [longUrl, setLongUrl] = useState('');
  const [customAlias, setCustomAlias] = useState('');
  const [activeMetrics, setActiveMetrics] = useState(null);
  const [error, setError] = useState('');

  const load = () => { fetch("http://localhost:5000/api/links").then(r => r.json()).then(setLinks); };
  useEffect(() => { load(); }, []);

  const send = (e: any) => {
    e.preventDefault(); setError('');
    fetch("http://localhost:5000/api/links", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ longUrl, customAlias }) })
      .then(async r => { const d = await r.json(); if (!r.ok) throw new Error(d.error || 'Conflict'); setLongUrl(''); setCustomAlias(''); load(); })
      .catch(err => setError(err.message));
  };

  return (
    <div style={{ maxWidth: "800px", margin: "40px auto", fontFamily: "system-ui, sans-serif", padding: "0 20px" }}>
      <h1>Trim Redirection Hub</h1>
      <form onSubmit={send} style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
        <input placeholder="Paste long destination URL here..." value={longUrl} onChange={e => setLongUrl(e.target.value)} required style={{ flex: 2, padding: "8px" }} />
        <input placeholder="Alias (Optional)" value={customAlias} onChange={e => setCustomAlias(e.target.value)} style={{ flex: 1, padding: "8px" }} />
        <button type="submit" style={{ padding: "8px 16px", background: "#2563eb", color: "#fff", border: "none", cursor: "pointer" }}>Trim Link</button>
      </form>
      {error && <p style={{ color: "red" }}>⚠️ {error}</p>}
      
      {activeMetrics && <AnalyticsView data={activeMetrics} onClose={() => setActiveMetrics(null)} />}

      <h2>Active Generated Shortcuts Registry</h2>
      {links.map((l: any) => (
        <div key={l.id} style={{ display: "flex", justifyContent: "space-between", padding: "12px", border: "1px solid #d1d5db", background: "#fff", marginBottom: "8px", borderRadius: "4px" }}>
          <div>
            <a href={l.shortUrl} target="_blank" rel="noreferrer" style={{ fontWeight: "bold" }}>{l.shortUrl}</a>
            <div style={{ fontSize: "0.85rem", color: "#6b7280" }}>{l.longUrl}</div>
          </div>
          <div>
            <span style={{ marginRight: "10px" }}>Clicks: {l.clicksCount}</span>
            <button onClick={() => { fetch('http://localhost:5000/api/links/' + l.shortCode + '/analytics').then(r => r.json()).then(setActiveMetrics); }} style={{ cursor: "pointer" }}>Analyze</button>
          </div>
        </div>
      ))}
    </div>
  );
}